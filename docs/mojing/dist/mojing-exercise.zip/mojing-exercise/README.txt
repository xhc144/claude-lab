墨经 Mojing · 习题与解答模板

本压缩包是自包含的：main.tex 为示例文档，mojing-*.cls / mojing-*.sty 为模板文件。

【本地编译】需要 TeX Live 2023 或更新版本（或 MiKTeX、MacTeX）：
    latexmk main.tex
  或者手动：xelatex main.tex（有参考文献时再运行 biber main，然后 xelatex 两遍）。

【Overleaf】新建项目 → Upload Project → 选择本 zip；
  然后在 Menu → Compiler 中选择 XeLaTeX，点 Recompile。

【字体】模板会自动选择中文字体：思源宋体 / Noto Serif CJK → macOS 宋体 → Windows 宋体 →
  TeX Live 自带的 Fandol。也可以用类选项强制指定，例如 \documentclass[cjk=fandol]{mojing-exercise}。

完整文档：https://github.com/xhc144/claude-lab/tree/main/mojing
